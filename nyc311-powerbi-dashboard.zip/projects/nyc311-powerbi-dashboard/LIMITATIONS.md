# Limitations

- The prepared Power BI inputs and browser preview use the pinned January 2024 cohort, not a live operational feed.
- The compact browser preview uses prepared agency/borough aggregates. Its medians and percentiles are computed from row-level eligible durations upstream; they must not be recomputed as averages of subgroup medians.
- NYC311 statuses and closure timestamps are administrative records. A Closed status does not establish satisfactory resolution.
- Some Closed records have no closure timestamp. Negative intervals occur only on non-Closed records in this cohort and are excluded from timing metrics.
- Long closure intervals and IQR flags are retained because they can represent real long-running cases. They are investigated, not automatically removed.
- There is no SLA definition, staffing denominator, case complexity control, causal design, or cross-period seasonal analysis. The report does not rank agency performance as quality.
- No native Power BI Desktop or Service report was opened, rendered, or published in this build environment. The supplied M and DAX are source definitions for reconstruction, and the live web dashboard is explicitly a preview.
