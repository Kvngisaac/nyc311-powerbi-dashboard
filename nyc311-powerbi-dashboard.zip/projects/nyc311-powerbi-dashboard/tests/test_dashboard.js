// Lightweight interaction regression test without browser dependencies.
const fs = require('node:fs');
const vm = require('node:vm');
const elements = new Map();
function el(id) {
  if (!elements.has(id)) elements.set(id, {id, value:'all', innerHTML:'', textContent:'', listeners:{}, addEventListener(type,fn){this.listeners[type]=fn;}});
  return elements.get(id);
}
global.document = {getElementById:el};
global.window = {};
vm.runInThisContext(fs.readFileSync('preview/data.js','utf8'));
vm.runInThisContext(fs.readFileSync('preview/app.js','utf8'));
function assert(condition,message){if(!condition)throw Error(message)}
assert(el('requests').textContent==='287,186','initial cohort total');
assert(el('eligible').textContent==='284,017','initial eligible denominator');
assert(el('median').textContent==='19.1h','initial median');
el('agency').value=encodeURIComponent('HPD');el('agency').listeners.change();
const expected=window.NYC311BI.views['HPD|all'].metrics.requests;
assert(el('requests').textContent===new Intl.NumberFormat('en-US').format(expected),'agency filter updates KPI');
el('borough').value=encodeURIComponent('Brooklyn');el('borough').listeners.change();
const slice=window.NYC311BI.views['HPD|Brooklyn'].metrics;
assert(el('requests').textContent===new Intl.NumberFormat('en-US').format(slice.requests),'combined filters update KPI');
assert(el('daily-chart').innerHTML.includes('<svg'),'daily chart redraws');
assert(el('problem-chart').innerHTML.includes('bar-row'),'problem bars redraw');
el('reset').listeners.click();
assert(el('requests').textContent==='287,186','reset restores cohort');
console.log('Passed: initial render, agency and combined filters, chart redraws, and reset.');
