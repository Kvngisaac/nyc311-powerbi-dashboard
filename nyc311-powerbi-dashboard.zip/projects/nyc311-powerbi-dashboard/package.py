"""Create a deterministic zip containing the reproducible Project 04 package."""
from __future__ import annotations

from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
DEST = ROOT.parent.parent / "dist" / "downloads" / "nyc311-powerbi-dashboard.zip"
EXCLUDED_PARTS = {"__pycache__", ".git"}


def main() -> None:
    DEST.parent.mkdir(parents=True, exist_ok=True)
    files = sorted(p for p in ROOT.rglob("*") if p.is_file() and not (EXCLUDED_PARTS & set(p.parts)))
    with zipfile.ZipFile(DEST, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
        for path in files:
            archive.write(path, path.relative_to(ROOT.parent.parent))
    print(f"Wrote {DEST} ({DEST.stat().st_size:,} bytes; {len(files)} files)")


if __name__ == "__main__":
    main()
