# Verification record

Generated with `prepare_powerbi.py` from the pinned Project 02 source snapshot without modifying Project 02.

- Fact rows: 287,186; request identifier uniqueness is checked during preparation.
- Agency / problem / borough / channel / status members: 14 / 172 / 6 / 5 / 7.
- Interactive filter slices exported: 105 (all + 14 agencies crossed with all + 6 borough options).
- Headline checks against the independently validated Project 02 model: 287,186 requests; 285,297 Closed; 284,017 timing-eligible; 1,280 Closed with missing closure date; 75 negative intervals; median 19.10 h; P90 668.55 h; mean 317.63 h; 152,789 within 24h (53.80% eligible); 3,809 zero durations; 49,374 upper-IQR flags retained.
- Independent raw-CSV validation: run `python validate.py results/` after preparation; the validator reports its own detailed comparisons.
- The generated compressed fact input was independently opened with Python `csv`/`gzip`: 287,186 rows, 287,186 unique request IDs, 284,017 eligible timing rows, and 152,789 within-24-hour eligible rows.
- `node tests/test_dashboard.js` passes initial render, agency and combined-filter changes, chart redraw, and reset behavior.
- DAX formulas and Power Query source are documented, but not executed by Microsoft Power BI Desktop here.
- Dashboard HTML/JS checks and data-versus-aggregate checks are separate from native Power BI validation.

Do not describe this artifact as a `.pbix` or published Power BI Service report.
