# Interview brief: NYC311 Operations BI

## 30-second explanation

I built an operations reporting case study from 287,186 NYC311 service requests created in January 2024. I pinned the public source extract, reused an audited Pandas cleaning pipeline, shaped the cohort into a fact-and-dimension model, and defined explicit DAX measures that separate total request volume from valid recorded closure-time observations. The report helps explore intake by date, agency, borough, and problem while making data limitations visible. The figures are descriptive and are not SLA or resolution-quality measures.

## Business problem

An operations analyst needs to describe request load and recorded closure intervals by service group and location, while ensuring missing and invalid timestamps do not distort the denominator. The report supports workload exploration and data-quality follow-up, not decisions about employee performance.

## Dataset

NYC Open Data’s 311 Service Requests dataset (`erm2-nwe9`). The chosen cohort is all requests created January 1–31, 2024. There are 287,186 records with 14 selected fields. Source hashes in the manifest make the snapshot reproducible even if the live dataset later changes.

## Cleaning and model decisions

- Inspect raw strings, schema, missingness, and duplicates before transformations.
- Normalize whitespace and null tokens while preserving identifiers such as ZIP codes as text.
- Parse timestamps using the source’s New York local-time context and calculate elapsed intervals consistently.
- Keep every accepted request for request-volume analysis.
- Define timing-eligible rows as Closed status with both timestamps and a nonnegative elapsed interval. Keep zero intervals. Exclude 1,280 Closed requests with no closure timestamp; the 75 negative intervals are all non-Closed.
- Retain extreme but valid durations. 49,374 rows fall beyond the upper Tukey IQR fence; this flag identifies a review population, not errors.
- Model one request per fact row with conformed Agency, Problem, Borough, Channel, Status, and Created Date dimensions.

## Findings to defend

- 287,186 total requests; 285,297 marked Closed (99.34% status share).
- 284,017 records qualify for recorded closure timing.
- Median recorded closure interval: 19.10 hours; mean: 317.63 hours; P90: 668.55 hours. The right-skewed tail makes the median a more representative center, while P90 communicates long waits.
- 152,789 of timing-eligible records are under 24 elapsed hours (53.80%). This is a descriptive threshold, not a published service target.
- The three most common problem categories have 114,540 requests (39.88%) in the Python analysis.

## Power BI techniques represented

The project includes a star-schema design, Power Query M import/type steps, explicit DAX measures, filter-aware denominators, and a report layout that separates intake from timing eligibility. CSV dimensions are deliberately pre-shaped so Power BI can focus on model relationships and analysis. The linked web preview demonstrates the filter and chart interaction; it is not represented as a native Power BI report.

## Validation

The Power BI fact table is generated from the same pinned and cleaned rows as Project 02. The cohort metrics and 105 agency/borough slices are compared with Project 02’s independently computed results. The source validator reads the raw CSV independently from the Pandas cleanup implementation. DAX and M have not been executed in Power BI Desktop in this environment, so explain that as a remaining validation step.

## Likely interview questions

**Why use a star schema?** It gives a clear one-to-many filter path from descriptive dimensions into a request-grain fact table and keeps measures reusable.

**Why does the timing denominator differ from total requests?** A recorded elapsed interval exists only for Closed rows with valid opening and closing timestamps and a nonnegative interval. The report exposes this eligible population explicitly.

**Why use median and P90 instead of only mean?** The distribution is strongly right-skewed. The mean can be pulled upward by a small number of very long recorded intervals; median and P90 describe the typical and tail experience.

**Why retain outliers?** The fence is a statistical flag, not proof of a data error. Removing long cases would understate the operational tail. They remain visible for investigation.

**Does Closed mean resolved?** No. It is the source’s administrative status. We cannot infer user satisfaction or substantive resolution from it.

**How do you know the result is trustworthy?** Source hash and row count are pinned; cleaning rules are explicit; an independent raw CSV validator checks aggregates; generated model metrics reconcile with the Python analysis; and each filter view has expected cohort counts.

**What would you do next in Power BI Desktop?** Import prepared tables, establish documented relationships, mark the date table, add measures, then reconcile cards and slicer combinations with `results/analysis.json` before publishing a `.pbix` or Service report.
