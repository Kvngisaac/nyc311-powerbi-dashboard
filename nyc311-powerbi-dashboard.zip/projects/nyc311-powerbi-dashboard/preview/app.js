'use strict';
const data = window.NYC311BI;
const agency = document.getElementById('agency');
const borough = document.getElementById('borough');
const fmt = new Intl.NumberFormat('en-US');
const pct = n => n == null ? '—' : `${(n * 100).toFixed(1)}%`;
const num = n => n == null ? '—' : fmt.format(n);
function option(select, values, allLabel) {
  select.innerHTML = `<option value="all">${allLabel}</option>` + values.map(v => `<option value="${encodeURIComponent(v)}">${v}</option>`).join('');
}
option(agency, data.agencies, 'All agencies'); option(borough, data.boroughs, 'All boroughs');
function getSlice() { return data.views[`${decodeURIComponent(agency.value)}|${decodeURIComponent(borough.value)}`] || data.default; }
function drawLine(daily) {
  const root = document.getElementById('daily-chart');
  if (!daily.length) { root.textContent = 'No rows in this selection.'; return; }
  const w=720,h=220,left=44,right=10,top=10,bottom=28, max=Math.max(...daily.map(x=>x.requests));
  const pts=daily.map((d,i)=>[left+i*(w-left-right)/Math.max(1,daily.length-1),top+(h-top-bottom)*(1-d.requests/max)]);
  const grid=[0,.5,1].map(v=>{let y=top+(h-top-bottom)*v;return `<line x1="${left}" y1="${y}" x2="${w-right}" y2="${y}" stroke="#e5e9e2"/><text x="0" y="${y+4}">${fmt.format(Math.round(max*(1-v)))}</text>`}).join('');
  let path=pts.map((p,i)=>`${i?'L':'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  root.innerHTML=`<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">${grid}<path d="${path}" fill="none" stroke="#166859" stroke-width="3" stroke-linejoin="round"/><circle cx="${pts[0][0]}" cy="${pts[0][1]}" r="3" fill="#d88f52"/><circle cx="${pts.at(-1)[0]}" cy="${pts.at(-1)[1]}" r="3" fill="#d88f52"/><text x="${left}" y="${h-4}">${daily[0].day.slice(5)}</text><text x="${w-right}" y="${h-4}" text-anchor="end">${daily.at(-1).day.slice(5)}</text></svg>`;
  const peakDay=daily.reduce((best,item)=>item.requests>best.requests?item:best,daily[0]);
  document.getElementById('daily-note').textContent=`${daily.length} cohort days · peak ${fmt.format(max)} requests on ${peakDay.day}`;
}
function drawBars(problems) {
  const items=problems.slice(0,10), max=Math.max(1,...items.map(x=>x.requests));
  document.getElementById('problem-chart').innerHTML=items.map(x=>`<div class="bar-row" title="${x.name}: ${fmt.format(x.requests)} requests"><span class="bar-name">${x.name}</span><span class="bar-track"><span class="bar-fill" style="width:${100*x.requests/max}%"></span></span><span class="bar-value">${fmt.format(x.requests)}</span></div>`).join('') || 'No categories in this selection.';
}
function render() {
  const slice=getSlice(), m=slice.metrics;
  document.getElementById('requests').textContent=num(m.requests);
  document.getElementById('closed').textContent=pct(m.closed_status_share);
  document.getElementById('closed-note').textContent=`${num(m.closed_status)} Closed status / ${num(m.requests)} requests`;
  document.getElementById('eligible').textContent=num(m.timing_eligible);
  document.getElementById('median').textContent=m.median_hours==null?'—':`${m.median_hours.toFixed(1)}h`;
  document.getElementById('p90').textContent=m.p90_hours==null?'—':`${fmt.format(Math.round(m.p90_hours))}h`;
  const full=data.default.metrics;
  document.getElementById('missing').textContent=num(full.closed_excluded_from_timing);
  document.getElementById('negative').textContent=num(full.negative_duration);
  document.getElementById('zeros').textContent=num(full.zero_duration);
  drawLine(slice.daily); drawBars(slice.problems);
  document.getElementById('selection').textContent=`${num(m.requests)} records in view`;
}
agency.addEventListener('change',render); borough.addEventListener('change',render);
document.getElementById('reset').addEventListener('click',()=>{agency.value='all';borough.value='all';render()});
render();
