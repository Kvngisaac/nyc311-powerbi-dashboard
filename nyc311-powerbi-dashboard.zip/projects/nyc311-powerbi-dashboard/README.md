# NYC311 Service Request Operations | Power BI Case Study

**Portfolio Slot 04 · Business Intelligence / Power BI**

This project turns a pinned public NYC311 cohort into a dimensional reporting model, documented Power Query and DAX, and an interactive dashboard preview. It reuses the Project 02 snapshot read-only; Projects 01–03 remain unchanged.

## Business question

How does January 2024 311 request intake vary by agency, borough, day, and problem type, and what do recorded closure intervals say about operational workload? Which data-quality limits must managers see before comparing response performance?

## Included

- `powerbi/Model-Guide.md`: star schema, relationships, grain, and report setup.
- `powerbi/PowerQuery.m`: M CSV import and type correction starter query.
- `powerbi/Measures.dax`: explicit measures and denominator logic.
- `data/FactRequests.csv.gz` and `data/Dim*.csv`: prepared Power BI import tables (the M query expands the compressed fact table).
- `data/dashboard-data.json`: aggregate data for the hosted interactive preview.
- `preview/index.html`: agency/borough filters, daily trend and top problem view.
- Reproducible Python preparation and validation source, requirements, raw source ZIP and manifest.
- Employer write-up, interview brief, verification record, and limitations.

## Dataset and method

Source: NYC Open Data, 311 Service Requests from 2020 to Present (dataset `erm2-nwe9`), 1–31 January 2024 creation cohort. The accepted cohort contains 287,186 requests and is pinned by SHA-256 in `source/manifest.json`. This is public historical data, not employer work. `prepare_powerbi.py` calls the Project 02 cleaning pipeline on a copy and creates dimensions plus a one-row-per-request fact table. It never edits Project 02.

Every accepted request contributes to volume. Timing includes only Closed records with valid, nonnegative recorded intervals. The report labels the eligible denominator, retains zero and extreme valid durations, and makes no SLA, causal, or resolution-quality claim.

## Reproduce

Python 3.11+ is recommended. From this folder:

```bash
python -m pip install -r requirements.txt
python prepare_powerbi.py
python validate.py results/
```

In Power BI Desktop, import the prepared CSVs, configure relationships following `powerbi/Model-Guide.md`, and add `powerbi/Measures.dax`. The M query assumes the extracted project path is updated. Desktop validation and native `.pbix` export were not possible in this environment. The live web report is an interactive preview, not a hosted Power BI Service report.

## Verification

Preparation produces 287,186 fact rows and 105 precomputed agency/borough filter views. Run the independent validator as above; see `VERIFICATION.md` and `LIMITATIONS.md` for exact coverage and remaining checks.
