"""Prepare a Power BI-ready star model and exact interactive report data.

The pinned source and cleaning code are the same audited snapshot used by
Project 02. This script writes only inside this Project 04 directory.
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from analysis import build_outputs, read_snapshot

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
RESULTS = ROOT / "results"


def dimension(frame: pd.DataFrame, source: str, key: str, label: str) -> tuple[pd.DataFrame, dict[str, int]]:
    values = sorted(frame[source].dropna().astype(str).unique(), key=lambda x: (x.casefold(), x))
    lookup = {value: i + 1 for i, value in enumerate(values)}
    table = pd.DataFrame([{key: lookup[value], label: value} for value in values])
    return table, lookup


def prepare() -> dict:
    DATA.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    raw, manifest = read_snapshot(ROOT)
    frame, model = build_outputs(raw, manifest, RESULTS)

    dims = {}
    lookups = {}
    for source, table, key, label in [
        ("agency_clean", "DimAgency", "AgencyKey", "Agency"),
        ("problem_clean", "DimProblem", "ProblemKey", "Problem"),
        ("borough_clean", "DimBorough", "BoroughKey", "Borough"),
        ("channel_clean", "DimChannel", "ChannelKey", "Channel"),
        ("status_clean", "DimStatus", "StatusKey", "Status"),
    ]:
        dims[table], lookups[table] = dimension(frame, source, key, label)
        dims[table].to_csv(DATA / f"{table}.csv", index=False, lineterminator="\n")

    f = pd.DataFrame({
        "RequestID": frame["unique_key"].astype("string"),
        "CreatedDate": frame["created_day"],
        "CreatedHour": frame["created_hour"].astype("Int64"),
        "CreatedWeekday": frame["created_weekday"],
        "AgencyKey": frame["agency_clean"].map(lookups["DimAgency"]).astype("int64"),
        "ProblemKey": frame["problem_clean"].map(lookups["DimProblem"]).astype("int64"),
        "BoroughKey": frame["borough_clean"].map(lookups["DimBorough"]).astype("int64"),
        "ChannelKey": frame["channel_clean"].map(lookups["DimChannel"]).astype("int64"),
        "StatusKey": frame["status_clean"].map(lookups["DimStatus"]).astype("int64"),
        "IsClosed": frame["is_closed"].astype(bool),
        "TimingEligible": frame["timing_eligible"].astype(bool),
        "Within24Hours": (frame["timing_eligible"] & frame["closure_seconds"].le(24 * 3600)).astype(bool),
        "ClosureSeconds": frame["closure_seconds"],
        "UpperIqrOutlier": frame["upper_iqr_outlier"].astype(bool),
        "ClosedMissingDate": (frame["is_closed"] & frame["closed_date_local"].isna()).astype(bool),
        "NegativeDuration": frame["negative_duration"].astype(bool),
        "NonClosedWithCloseDate": ((~frame["is_closed"]) & frame["closed_date_local"].notna()).astype(bool),
        "FutureClose": frame["future_close"].astype(bool),
        "ZeroDuration": (frame["timing_eligible"] & frame["closure_seconds"].eq(0)).astype(bool),
        "UnknownZip": frame["incident_zip"].isna().astype(bool),
        "InvalidNonmissingZip": (frame["incident_zip"].notna() & ~frame["zip_valid"]).astype(bool),
    })
    assert f["RequestID"].is_unique
    assert len(f) == manifest["raw_rows"] - model["quality"]["exact_duplicate_rows_removed"] - model["quality"]["quarantined_rows"]
    f.to_csv(DATA / "FactRequests.csv.gz", index=False, lineterminator="\n", na_rep="",
             compression={"method": "gzip", "compresslevel": 6, "mtime": 0})

    dates = pd.date_range(manifest["cohort_start"], pd.Timestamp(manifest["cohort_end_exclusive"]) - pd.Timedelta(days=1), freq="D")
    dim_date = pd.DataFrame({
        "Date": dates.strftime("%Y-%m-%d"),
        "DayOfMonth": dates.day,
        "WeekdayNumberMonday0": dates.dayofweek,
        "Weekday": dates.day_name(),
        "IsWeekend": dates.dayofweek >= 5,
    })
    dim_date.to_csv(DATA / "DimDate.csv", index=False, lineterminator="\n")

    q = model["views"]
    compact = {
        "cohort": model["cohort"],
        "snapshot_utc": model["snapshot_utc"],
        "source_url": model["source_url"],
        "source_sha256": model["source_raw_sha256"],
        "agencies": model["agencies"],
        "boroughs": model["boroughs"],
        "default": q["all|all"],
        "views": {
            key: {"metrics": val["metrics"], "daily": val["daily"], "problems": val["problems"],
                  "duration_bins": val["duration_bins"]}
            for key, val in q.items()
        },
    }
    (DATA / "dashboard-data.json").write_text(json.dumps(compact, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")

    audit = model["quality"]
    summary = {
        "source_rows": manifest["raw_rows"],
        "accepted_requests": audit["accepted_requests"],
        "exact_duplicate_rows_removed": audit["exact_duplicate_rows_removed"],
        "quarantined_rows": audit["quarantined_rows"],
        "closed_missing_date": audit["closed_status_missing_close_date"],
        "negative_intervals": audit["negative_duration_requests"],
        "upper_iqr_flags_retained": audit["closure_time_eligible_requests"] and model["views"]["all|all"]["metrics"]["upper_iqr_outliers"],
        "zero_durations_retained": model["views"]["all|all"]["metrics"]["zero_duration"],
        "source_sha256": manifest["raw_sha256"],
        "filters_reconciled": len(model["views"]),
    }
    (RESULTS / "powerbi-preparation.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return {"rows": len(f), "views": len(q), "dimensions": {k: len(v) for k, v in dims.items()},
            "metrics": model["views"]["all|all"]["metrics"], "summary": summary}


if __name__ == "__main__":
    print(json.dumps(prepare(), indent=2))
