// Power Query M starter query. Set ProjectFolder to the extracted project root.
// Prepared CSVs preserve the audited Python cleaning policy and avoid repeating
// row-level timestamp parsing in Power BI.
let
    ProjectFolder = "C:\\path\\to\\nyc311-powerbi-dashboard",
    DataFolder = ProjectFolder & "\\data\\",
    Compressed = Binary.Decompress(File.Contents(DataFolder & "FactRequests.csv.gz"), Compression.GZip),
    Source = Csv.Document(
        Compressed,
        [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]
    ),
    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Types = Table.TransformColumnTypes(Headers, {
        {"RequestID", type text}, {"AgencyKey", Int64.Type},
        {"ProblemKey", Int64.Type}, {"BoroughKey", Int64.Type},
        {"ChannelKey", Int64.Type}, {"StatusKey", Int64.Type},
        {"CreatedDate", type date}, {"CreatedHour", Int64.Type},
        {"IsClosed", type logical}, {"TimingEligible", type logical},
        {"Within24Hours", type logical}, {"ClosureSeconds", type number}
    }, "en-US")
in
    Types

// Duplicate the query for each dimension by changing FactRequests.csv to the
// matching DimAgency.csv, DimProblem.csv, DimBorough.csv, DimChannel.csv,
// DimStatus.csv, or DimDate.csv and applying suitable column types.
