# Power BI model and report guide

## Grain and relationships

`FactRequests` has exactly one row per accepted NYC311 `unique_key` (287,186 rows). `DimAgency`, `DimProblem`, `DimBorough`, `DimChannel`, and `DimStatus` each have one row per stable dimension key. `DimDate` has one row per date in the January 2024 cohort.

Create one-to-many, single-direction relationships from each dimension key to its matching `FactRequests` foreign key. Relate `DimDate[Date]` to `FactRequests[CreatedDate]`. Do not relate dimensions to one another. Mark `DimDate` as the date table. Keep `RequestID` as a text identifier and do not summarize it.

## Report layout

1. **Operations overview**: request count, closed-status share, eligible timing count, median recorded closure, P90 recorded closure; date trend and top problem types.
2. **Workload comparison**: agency/borough slices with request counts and closure distribution; show the eligible denominator beside timing measures.
3. **Data quality**: missing closure timestamp, negative intervals, zero-duration and long-tail flags. These are investigation indicators, not a scorecard.

Use agency and borough slicers consistently across pages. Give every timing visual a visible eligibility definition; volume always uses the full cohort. Use a neutral title such as “Recorded closure interval,” never “time to resolve” or “SLA compliance.”

## Data refresh

The public Socrata dataset changes over time. This case study uses a frozen extract and manifest. To refresh, download a candidate snapshot, review schema and row-level differences, update the source manifest only after validation, rerun preparation, and compare every headline measure. Do not silently replace the pinned extract.
